<template>
    <div class="filter">
        <ul>
            <li>
              <input type="checkbox" id="check_1" name="check_1" value="check_1">
              <label for="check_1">XS</label>
            </li>
            <li>
              <input type="checkbox" id="check_2" name="check_2" value="check_2">
              <label for="check_2">S</label>
            </li>
            <li>
              <input type="checkbox" id="check_3" name="check_3" value="check_3">
              <label for="check_3">M</label>
            </li>
            <li>
              <input type="checkbox" id="check_4" name="check_4" value="check_4">
              <label for="check_4">L</label>
            </li>
            <li>
              <input type="checkbox" id="check_5" name="check_5" value="check_5">
              <label for="check_5">XL</label>
            </li>
            <li>
              <input type="checkbox" id="check_6" name="check_6" value="check_6">
              <label for="check_6">XXL</label>
            </li>
          </ul>
    </div>
</template>
  
<script>
  export default{
    name : 'ClothesSize',
    data(){
    return {sizes : ['XS','S','M','L ','XL','XXL']
  }}
  }
</script>
  
<style>
    div ul{
        display: flex;
        justify-content: space-around;
        flex-wrap: wrap;
    }
    ul {
        padding: 0;
        margin: 0;
        clear: both;
      }
      
      li{
        list-style-type: none;
        list-style-position: outside;
        padding: 10px;
        float: left;
      }
      
      input[type="checkbox"]:not(:checked), 
      input[type="checkbox"]:checked {
        position: absolute;
        left: -9999%;
      }
      
      input[type="checkbox"] + label {
        display: inline-block;
        padding: 10px;
        cursor: pointer;
        border: 1px solid black;
        border-radius: 50%;
        color: black;
        background-color: white;
        margin-bottom: 10px;
        width: 50px;
      }
      
      input[type="checkbox"]:checked + label {
        border: 1px solid white;
        color: white;
        background-color: black;
      }
   
</style>
