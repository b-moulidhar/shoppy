<template>
  <div>
    <HeaderOne/>
    <div class="row section_2">
      <div class="col-xxl-3"><ClothesSize/></div>
      <div class="col-xxl-9"><ProductsVue/></div>
    </div>
  </div>
</template>

<script>
import HeaderOne from './components/HeaderOne.vue'
import ClothesSize from './components/ClothesSize.vue'
import ProductsVue from './components/ProductsVue.vue';
export default {
  name: 'App',
  components: {
    HeaderOne,
    ClothesSize,
    ProductsVue
  }
}
</script>

<style>
  .section_2{
    margin-top: 15px;
  }
</style>
