<template>
    <div class="filter">
        <h2 class="heading_size">Sizes :</h2>
        <ul>
            <li v-for="(size,key) in sizes" :key="key">
              
              <input @change="$emit('val1',size)" type="checkbox" v-model="size[key]" :id="key" name="check_2" value="check_2">
              <label :for="key">{{size}}</label>
            
            </li>
          </ul>
    </div>
</template>
  
<script>
  export default{
    name : 'ClothesSize',
    data(){
    return {sizes : ['XS','S','M','L ','XL','XXL']
  }}
  }
</script>
  
<style>
    div ul{
        float: left;
    }
    ul {
        padding: 0;
        margin: 0;
        clear: both;
    }
    
    li{
    list-style-type: none;
    list-style-position: outside;
    padding: 10px;
    float: left;
    }
    
    input[type="checkbox"]:not(:checked), 
    input[type="checkbox"]:checked {
    position: absolute;
    left: -9999%;
    }
    
    input[type="checkbox"] + label {
    display: inline-block;
    padding: 10px;
    cursor: pointer;
    border: 1px solid rgb(172, 169, 169);
    border-radius: 50%;
    color: black;
    background-color:#ced4da;
    margin-bottom: 10px;
    width: 45px;
    }
    
    input[type="checkbox"]:checked + label {
        border: 1px solid white;
        color: white;
        background-color: black;
    }

    label{
        font-size: 14px;
    }

    .heading_size{
        text-align: left;
        font-size: 24px;
        font-weight: bold;
    }

    .filter{
        display: flex;
        flex-direction: column;
        justify-content: center;
    }
   
</style>
