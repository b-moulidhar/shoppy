
  
<style>
nav{
        height: 56px;
        display: flex;
        align-items: center;
        justify-content: flex-end;
    }
    .cart_qty{
        width: 80px;
        height: 56px;
        background-color: black;
        padding: 10px;
    }
    .badge {
        padding-left: 19px;
        padding-right: 19px;
        -webkit-border-radius: 9px;
        -moz-border-radius: 19px;
        border-radius: 19px;
    }
    .label-warning[href],
    .badge-warning[href] {
    background-color: #c67605;
}

#lblCartCount {
    font-size: 18px;
    background: #ffb703;
    color: rgb(10, 9, 9);
    padding: 0 12px;
    vertical-align: bottom;
    margin-left: -15px;
}

.cart_qty img{
    filter: invert(1);
    cursor: pointer;
}

.cart_in_qty{
    filter: invert(1)
}   

.cart_items{
    display: flex;
    gap: 2rem;
    justify-content: center;
}

.cart_items img{
    max-width: 80px;
}

.cart_content{
    text-align: left;
}
.cart_content h2{
    color: white;
    font-size: 24px;
}
.cart_content p{
    color: grey;
    font-size: 18px;
}
.cart_content2{
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}
.cart_content2 button{
    background: none;
    border: none;
}
.cart_content2 button p{
    font-weight: bold;
    font-size: 20px;
}
.cart_content2 button:hover{
    color :  #ffb703;
}

.cart_content2 p{
    color :  #ffb703;
}

.quantity{
    display: flex;
    gap : 0rem;
}

.quantity button{
    border: 1px solid black;
    color : white;
    background-color:black ;
}


body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 35%;
    position: fixed;
    z-index: 1;                            
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
    .sidenav {padding-top: 15px;}
    .sidenav a {font-size: 18px;}
}

</style>

<template>
<!-- <nav>
    <div class="cart_qty">
        <img src="../assets/cart_40px.png" alt=""/>
        <span class="badge badge-warning" id="lblCartCount">0</span>
    </div>
</nav> -->

<nav>
    <div id="mySidenav" class="sidenav">
        <a href="javascript:void(0)" class="closebtn" @click="closeNav">&times;</a>
        <div>
            <header class="cart_in_qty">
                <img src="../assets/cart_40px.png" alt=""/>
                <span class="badge badge-warning" id="lblCartCount">{{propers.length}}</span>
            </header>
            <hr>
            <div>
                <div v-if="propers[0]==null">your cart is empty</div>
                <div v-else  v-for="(products,key) in propers" :key="key" class="cart_items">
                    <div>
                        <img v-bind:src="products.image" alt="">
                    </div>
                    <div class="cart_content">
                        <h2>{{products.style}}</h2>
                        <p>{{products.title}}</p>
                        <p>Quantity:1</p>
                    </div>
                    <div class="cart_content2">
                        <button><span>X</span></button>
                        <p>${{products.price}}</p>
                        <div class="quantity">
                            <button>-</button>
                            <button>+</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="cart_qty" @click="openNav">
        <img src="../assets/cart_40px.png" alt=""/>
        <span class="badge badge-warning" id="lblCartCount">{{propers.length}}</span>
    </div>
</nav>
</template>
<script>
import {inject} from 'vue';
export default{
    name:'HeaderOne',
    data(){
        return{
            propers : inject('name')
        }
    },
    methods:{
        openNav() {
            document.getElementById("mySidenav").style.width = "250px";
        },
        closeNav() {
            document.getElementById("mySidenav").style.width = "0";
        }
    },
    // inject:['name']
}
</script>