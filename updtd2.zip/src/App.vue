<template>
  <div>
    <!-- <router-link to="/"><HeaderOne/></router-link> -->
    <!-- <router-link to="/"><HeaderOne/></router-link> -->
    <HeaderOne/>
    <div class="row section_2 container">
      <div class="col-xxl-3 col-xl-2 col-lg-2 col-md-3 col-sm-1"><ClothesSize v-on:val1="sizes($event)"/></div>
      <div class="col-xxl-9 col-xl-10 col-lg-10 col-md-9 col-sm-11"><ProductsVue v-on:addtocart="mett($event)"/></div>
      <!-- <div class="col-xxl-2 col-xl-2 col-lg-2 col-md-2 col-sm-1"><router-view/></div> -->
    </div>
   
  </div>
</template>
<script>
import HeaderOne from './components/HeaderOne.vue'
import ClothesSize from './components/ClothesSize.vue'
import ProductsVue from './components/ProductsVue.vue';
export default {
  name: 'NameApp',
  created(){
    this.$store.dispatch('getProductsAction')
  },
  data(){
    return{
      cart:[],
      size : []
    }
  },
  components: {
    HeaderOne,
    ClothesSize,
    ProductsVue
  },
  provide(){
    return{
          name : this.cart
    }
  },
  methods:{
    mett(person){
      return  this.cart.push(person)
    },
    sizes(val){
      return this.size.push(val)
    }
  }
}
</script>

<style>
  .section_2{
    margin: 50px auto;
  }

  @media screen and (max-width : 820px) {
    
  }
</style>
